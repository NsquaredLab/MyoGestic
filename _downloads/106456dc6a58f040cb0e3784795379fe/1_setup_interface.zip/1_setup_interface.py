"""
====================================
Part 1: Setup Interface
====================================

The setup interface is the first component of a visual interface in
MyoGestic.  It is responsible for:

- Configuring VI-specific parameters (ports, executable paths, etc.).
- Launching and stopping the external VI process.
- Managing bi-directional communication (outgoing predictions, incoming
  kinematics) via UDP or another protocol.
- Providing custom signals and data buffers for the Online protocol.

Step 1: Create the UI
-----------------------
Design a Qt ``.ui`` file with at least a ``groupBox`` containing a
start/stop button.  Convert it with ``pyside6-uic``.

.. note::
   Copy an existing UI file from
   ``myogestic/gui/widgets/visual_interfaces/virtual_hand_interface/ui/``
   as a starting point.

Step 2: Understand the Base Class
----------------------------------
Your setup interface must inherit from:

.. currentmodule:: myogestic.gui.widgets.templates.visual_interface
.. autosummary:: SetupInterfaceTemplate
    :toctree: generated/visual_interface

The base class provides:

- :attr:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate.outgoing_message_signal` (``Signal(QByteArray)``) -- Send data to
  the VI.
- :attr:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate.incoming_message_signal` (``Signal(np.ndarray)``) -- Receive data
  from the VI.
- :attr:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate._main_window` -- Reference to the main MyoGestic application.
- :attr:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate._record_protocol`, :attr:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate._training_protocol`, :attr:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate._online_protocol` --
  Protocol references.

You **must** implement these abstract methods:

- :meth:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate.initialize_ui_logic` -- Wire up UI widgets.
- :meth:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate.start_interface` -- Launch the VI process.
- :meth:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate.stop_interface` -- Stop the VI process.
- :meth:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate.interface_was_killed` -- Handle unexpected VI termination.
- :meth:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate.close_event` -- Clean up on application exit.
- :meth:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate.connect_custom_signals` / :meth:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate.disconnect_custom_signals` --
  Connect/disconnect data streaming signals.
- :meth:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate.clear_custom_signal_buffers` -- Reset internal data buffers.

Optionally override:

- :meth:`~myogestic.gui.widgets.templates.SetupInterfaceTemplate.get_custom_save_data` -- Return extra data to include
  when saving recordings (e.g., predicted hand positions).

Step 3: Implement the Setup Interface
---------------------------------------
Below is a minimal self-contained example, followed by references to
the full VHI implementation.

"""

# %%
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# Step 3.1: Minimal Setup Interface
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# This shows the skeleton of a setup interface.  In practice, you would
# add UDP socket management, process launching, and data streaming.

import numpy as np
from PySide6.QtCore import QByteArray
from PySide6.QtGui import QCloseEvent

from myogestic.gui.widgets.templates.visual_interface import SetupInterfaceTemplate


class MyInterface_SetupInterface(SetupInterfaceTemplate):
    """Minimal setup interface example."""

    def __init__(self, main_window, name: str = "MyInterface"):
        # Import your generated UI class:
        # from myogestic.gui.widgets.visual_interfaces.my_interface.ui import Ui_MySetup
        # super().__init__(main_window, name, ui=Ui_MySetup())
        #
        # For this example we pass None (won't run without a real UI):
        pass  # Replace with super().__init__(...)

    def initialize_ui_logic(self) -> None:
        """Wire up buttons, labels, and other UI elements."""
        pass

    def start_interface(self) -> None:
        """Launch the external VI process and start UDP communication."""
        pass

    def stop_interface(self) -> None:
        """Stop the VI process and close sockets."""
        pass

    def interface_was_killed(self) -> None:
        """Handle unexpected VI termination (e.g., user closed window)."""
        pass

    def close_event(self, event: QCloseEvent) -> None:
        """Clean up on application exit."""
        pass

    def connect_custom_signals(self) -> None:
        """Connect data streaming signals (called when online starts)."""
        pass

    def disconnect_custom_signals(self) -> None:
        """Disconnect data streaming signals (called when online stops)."""
        pass

    def clear_custom_signal_buffers(self) -> None:
        """Reset internal data buffers."""
        pass

    def get_custom_save_data(self) -> dict:
        """Return extra data to include when saving recordings."""
        return {}


# %%
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# Step 3.2: VHI Reference -- Class Definition and Helpers
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# The VHI setup interface launches a Unity executable, manages UDP
# communication on multiple ports, and streams kinematics at 32 Hz.
#
# .. literalinclude:: /../../myogestic/gui/widgets/visual_interfaces/virtual_hand_interface/setup_interface.py
#    :language: python
#    :linenos:
#    :lines: 1-40
#    :caption: Imports
#
# .. literalinclude:: /../../myogestic/gui/widgets/visual_interfaces/virtual_hand_interface/setup_interface.py
#    :language: python
#    :lineno-match:
#    :pyobject: VirtualHandInterface_SetupInterface.__init__
#    :caption: Constructor

# %%
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# Step 3.3: VHI Reference -- Lifecycle Methods
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#
# .. literalinclude:: /../../myogestic/gui/widgets/visual_interfaces/virtual_hand_interface/setup_interface.py
#    :language: python
#    :lineno-match:
#    :pyobject: VirtualHandInterface_SetupInterface.start_interface
#    :caption: start_interface -- Launch Unity and open UDP sockets
#
# .. literalinclude:: /../../myogestic/gui/widgets/visual_interfaces/virtual_hand_interface/setup_interface.py
#    :language: python
#    :lineno-match:
#    :pyobject: VirtualHandInterface_SetupInterface.stop_interface
#    :caption: stop_interface -- Stop Unity and close sockets

# %%
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# Step 3.4: VHI Reference -- Communication and Streaming
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#
# .. literalinclude:: /../../myogestic/gui/widgets/visual_interfaces/virtual_hand_interface/setup_interface.py
#    :language: python
#    :lineno-match:
#    :pyobject: VirtualHandInterface_SetupInterface.toggle_streaming
#    :caption: toggle_streaming -- Start/stop data streaming
#
# .. literalinclude:: /../../myogestic/gui/widgets/visual_interfaces/virtual_hand_interface/setup_interface.py
#    :language: python
#    :lineno-match:
#    :pyobject: VirtualHandInterface_SetupInterface.read_message
#    :caption: read_message -- Read UDP messages from the VI

# %%
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# Step 3.5: VHI Reference -- Custom Signals and Data
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#
# .. literalinclude:: /../../myogestic/gui/widgets/visual_interfaces/virtual_hand_interface/setup_interface.py
#    :language: python
#    :lineno-match:
#    :pyobject: VirtualHandInterface_SetupInterface.connect_custom_signals
#    :caption: connect_custom_signals
#
# .. literalinclude:: /../../myogestic/gui/widgets/visual_interfaces/virtual_hand_interface/setup_interface.py
#    :language: python
#    :lineno-match:
#    :pyobject: VirtualHandInterface_SetupInterface.get_custom_save_data
#    :caption: get_custom_save_data -- Extra recording data (predicted hand positions)

# %%
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# Step 3.6: Registration in CONFIG_REGISTRY
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# Both the setup and recording interfaces are registered together.
# This is typically done in :mod:`~myogestic.default_config` or :mod:`~myogestic.user_config`.
#
# .. code-block:: python
#
#    from myogestic.utils.config import CONFIG_REGISTRY
#    from myogestic.gui.widgets.visual_interfaces.virtual_hand_interface import (
#        VirtualHandInterface_SetupInterface,
#        VirtualHandInterface_RecordingInterface,
#    )
#
#    CONFIG_REGISTRY.register_visual_interface(
#        name="VHI",
#        setup_interface_ui=VirtualHandInterface_SetupInterface,
#        recording_interface_ui=VirtualHandInterface_RecordingInterface,
#    )
