"""
How to use MyoGestic
================================

This tutorial will guide you through the process of using MyoGestic to train a model to predict hand gestures from EMG data.
"""

# %%
# Tutorial Video
# --------------
# .. youtube:: Re3VfgKhjCM
#    :width: 800
